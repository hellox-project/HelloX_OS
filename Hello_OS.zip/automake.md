##automake

###8.3.9.1 Error: 鈥榬equired file `./ltmain.sh' not found鈥�
	http://www.gnu.org/software/automake/manual/html_node/Error-required-file-ltmain_002esh-not-found.html
	http://stackoverflow.com/questions/22603163/automake-error-ltmain-sh-not-found
	
	
__declspec(naked)
	