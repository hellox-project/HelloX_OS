
//Restore the default alignment.
#pragma pack(pop)
