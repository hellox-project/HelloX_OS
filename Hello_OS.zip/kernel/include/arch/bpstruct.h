
//Use 1 byte alignment.
#pragma pack(push,1)
