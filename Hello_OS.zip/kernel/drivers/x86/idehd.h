//Hard disk driver simulation driver.
//This driver use windows API to access physical HD directly.

#ifndef __WINHD_H__
#define __WINHD_H__
#endif

//Driver entry.
BOOL IDEHdDriverEntry(__DRIVER_OBJECT* pDrvObj);
