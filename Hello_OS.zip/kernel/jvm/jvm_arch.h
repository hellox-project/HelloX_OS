#ifndef __JVM_ARCH_H__
#define __JVM_ARCH_H__

#include "arch/i386.h"

#endif  //__JVM_ARCH_H__
