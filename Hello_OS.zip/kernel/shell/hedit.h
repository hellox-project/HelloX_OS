//***********************************************************************/
//    Author                    : Garry
//    Original Date             : 26 FEB,2009
//    Module Name               : HEDIT.H
//    Module Funciton           : 
//                                HEDIT application's definitions.
//    Last modified Author      :
//    Last modified Date        :
//    Last modified Content     :
//                                1.
//                                2.
//    Lines number              :
//***********************************************************************/

#ifndef __HEDIT_H__
#define __HEDIT_H__
#endif

//Main entry of HEDIT application.
DWORD heditEntry(LPVOID);
