//***********************************************************************/
//    Author                    : Garry
//    Original Date             : Jul,03 2005
//    Module Name               : SYSD_S.H
//    Module Funciton           : 
//                                This module countains system diag application's pre-
//                                definitions.
//                                This file countains shell command or application code,
//                                as the name of this file is ended by "_S".
//    Last modified Author      :
//    Last modified Date        :
//    Last modified Content     :
//                                1.
//                                2.
//    Lines number              :
//***********************************************************************/

#ifndef __SYSD_S_H__
#define __SYSD_S_H__

DWORD SysDiagStart(LPVOID);    //Entry point of the sys diag application.

//
//The following constants are returned by CommandParser.
//

/*#define SYS_DIAG_CMD_PARSER_TERMINAL      0x00000000
#define SYS_DIAG_CMD_PARSER_SUCCESS       0x00000001
#define SYS_DIAG_CMD_PARSER_INVALID       0x00000002
#define SYS_DIAG_CMD_PARSER_PROCESSING    0x00000003
#define SYS_DIAG_CMD_PARSER_FAILED        0x00000004*/

#endif
