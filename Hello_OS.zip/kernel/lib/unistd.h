//***********************************************************************/
//    Author                    : Garry
//    Original Date             : April 17,2015
//    Module Name               : signal.h
//    Module Funciton           : 
//                                Simulates POSIX unistd.h file.
//    Last modified Author      :
//    Last modified Date        :
//    Last modified Content     :
//                                1.
//                                2.
//    Lines number              :
//***********************************************************************/

#ifndef __UNISTD_H__
#define __UNISTD_H__

#endif //__UNISTD_H__
