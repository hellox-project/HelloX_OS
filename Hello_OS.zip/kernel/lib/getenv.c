//Implementation code of getenv routine.

#include <StdAfx.h>
#include <stdlib.h>

char *_hx_getenv(char *envvar)
{
	return NULL;
}
