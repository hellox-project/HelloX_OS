//Only implements fmod routine,which is refered by interpreter of JVM.

#ifndef __MATH_H__
#define __MATH_H__

//Calculate the remainder of x/y.
double fmod(double x,double y);

//Get the floor of x.
double floor(double x);

#endif //__MATH_H__
