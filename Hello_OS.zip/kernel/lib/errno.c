//Error number related souce code.
#include <StdAfx.h>
#include <errno.h>

//Error number.
int errno = 0;

