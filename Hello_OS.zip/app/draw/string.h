
char* strcat(char* dst,const char* src);
char* strcpy(char* dst,const char* src);
char* strchr(const char* string,int ch);
int strcmp(const char* src,const char* dst);
int strlen(const char* s);

long atol(const char* nptr);
int atoi(const char* nptr);

