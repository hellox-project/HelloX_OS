#!/bin/bash

autoreconf && automake && ./configure;
